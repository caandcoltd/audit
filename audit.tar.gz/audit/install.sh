#!/usr/bin/env bash

function installAudit() {
  useRemotePG=$1

  if [ ${useRemotePG} == "true" ]; then
    echo -e "\e[93mPlease specify your user in postgres\e[39m"
    read -r user
    if [[ -z "${user}" ]]; then
        return 0;
    fi;

    echo -e "\e[93mPlease specify your user password in postgres\e[39m"
    read -r password
    if [[ -z "${password}" ]]; then
        return 0;
    fi;

    echo -e "\e[93mPlease specify your hostname with port postgres (ex: postgres:5432)\e[39m"
    read -r host
    if [[ -z "${host}" ]]; then
        return 0;
    fi;

    echo -e "\e[93mPlease specify your dbname in postgres\e[39m"
    read -r dbname
    if [[ -z "${dbname}" ]]; then
        return 0;
    fi;

    microk8s helm3 upgrade --install audit helm.tar.gz --set global.psql_url=postgresql://$user:$password@$host/$dbname?sslmode=disable
    return 1;
  fi


  if [[ -z $(microk8s kubectl get namespace | grep "audit") ]]; then
    microk8s kubectl create namespace audit
  fi;
  if [[ -z $(microk8s kubectl get secret -n audit | grep "yandexsecret") ]]; then
    microk8s kubectl get secret yandexsecret -o yaml | sed 's/default/audit/g' | microk8s kubectl -n audit apply -f -
  fi;
  if [[ -n "$(microk8s helm3 list -n audit | grep -w '^postgres')" ]]; then
    microk8s helm3 uninstall postgres -n audit
  fi;
  microk8s helm3 install postgres ./postgres-statefulset -n audit
  if [[ -n "$(microk8s helm3 list -n audit | grep -w '^audit')" ]]; then
    microk8s helm3 uninstall audit -n audit
  fi;
  microk8s helm3 install audit helm.tar.gz --set global.psql_url=postgresql://postgres:pgpassword@postgres:5432/audit?sslmode=disable --set global.namespace=audit -n audit
  echo "Audit service url: http://audit.audit.svc:3000"
  return 1;
}

microk8s enable helm3
echo -e "\e[93mDo you want to specify your Postgres? (y/N)\e[39m"
read -r yn
case $yn in
    [Yy]* ) installAudit "true";;
    [Nn]* ) installAudit "false";;
    * ) echo "skipping";;
esac
